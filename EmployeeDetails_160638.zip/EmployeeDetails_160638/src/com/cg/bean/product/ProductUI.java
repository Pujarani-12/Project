package com.cg.bean.product;

import java.util.Scanner;

public class ProductUI extends Product{
	static Scanner sc=new Scanner(System.in);
	static ProductCollection coll=null;
	
	

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		while(true)
		{
			System.out.println("----------------------------------------------");
			System.out.println("---------Product Details----------------------");
			System.out.println("1.Add Product Details");
			System.out.println("2.Display Product Details");
			System.out.println("3.Exit");
			
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				addProductDetails();
				break;
			case 2:
				display();
				
				break;
			
			case 3:
				sc.close();
				System.exit(0);
			default:
				System.exit(0);
			}
		}

	}
	
	public static void addProductDetails() {
		
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("Enter Your Product ID");
			String prodId=sc.next();
			
			if(ProductValidate.isValidateprodId(prodId))
			{
				System.out.println("Enter the Product Name");
				String prodName=sc.next();
			if(ProductValidate.isValidateprodName(prodName))
			{
				System.out.println("Enter the Product Type");
				String prodType=sc.next();
			if(ProductValidate.isValidateprodType(prodType))
			{
				System.out.println("Enter the Product Price");
				String prodPrice=sc.next();
			if(ProductValidate.isValidateprodprodPrice(prodPrice))
			{
				Product prod=new Product(Integer.parseInt(prodId),prodName,prodType,Double.parseDouble(prodPrice));
				ProductCollection.addProductDetails(prod);
				break;
			}
			else
				System.out.println("Invalid Price!!Please enter a valid double type as price");
			}
			else
				System.out.println("Invalid Type!!Please put a valid type from the list");
			}
			else
				System.out.println("Invalid Name!!Please put a valid pattern name");
			}
			else
				System.out.println("Invalid ID!!Please provide a valid # digit as ID");
			
		}
		while(true);
		System.out.println("The Details have been updated successfully");
	}
	
	public static void display()
	{
		System.out.println("Product Type          \t  Discount");
		System.out.println("-----------------------------------------");
		System.out.println("1.Groceries                    10%");
		System.out.println("2.Toys                         20%");
		System.out.println("3.Electronics   			   30%");
		System.out.println("4.Home Appliances   		   40%");
		ProductCollection.displayDiscount();
		//ProductCollection.displayProdCount();
	}
	
	

}
