package com.cg.bean.product;

public class Product {
	int ProdId;
	String ProdName;
	String ProdType;
	Double ProdPrice;
	
	
	//Generating default Constructor
	public Product() {
		super();
	}

	
	//Generating parameterized Constructor
	public Product(int prodId, String prodName, String prodType, Double prodPrice) {
		super();
		ProdId = prodId;
		ProdName = prodName;
		ProdType = prodType;
		ProdPrice = prodPrice;
	}



	//Generating getters and setters
	public int getProdId() {
		return ProdId;
	}


	public void setProdId(int prodId) {
		ProdId = prodId;
	}


	public String getProdName() {
		return ProdName;
	}


	public void setProdName(String prodName) {
		ProdName = prodName;
	}


	public String getProdType() {
		return ProdType;
	}


	public void setProdType(String prodType) {
		ProdType = prodType;
	}


	public Double getProdPrice() {
		return ProdPrice;
	}


	public void setProdPrice(Double prodPrice) {
		ProdPrice = prodPrice;
	}


	@Override
	public String toString() {
		return " ProdId=" + ProdId + "\n ProdName=" + ProdName + "\n ProdType=" + ProdType + "\n ProdPrice="
				+ ProdPrice + "";
	}
	
	
	

}
