package com.cg.bean.product;

public @interface Test {

}
