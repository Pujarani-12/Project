package com.cg.bean.product;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.Test;

public class TestCase {

	static ProductCollection v;
	static Product e=null;
	
	@BeforeClass
	public   static  void beforeClass()
	{
		v=new ProductCollection();
		e =new Product(111,"Namanawasthi","ADCSS12345",123.00);		
	}
	@AfterClass
	public static  void afterClass()
	{		
		v=null;
		e=null;
	}	
	
	
	@Test 
	public void testaddProductDetails() 
	{
		ProductCollection.addProductDetails(e);
		//Assert.assertEquals(4, collectionHelper.getCustList().size());
		Assert.assertNotNull(e.toString());
		
	}
	
	@Test 
	public void display()
	{
		ProductCollection.display();
	}
}