package com.cg.bean.product;

import java.util.ArrayList;
import java.util.Iterator;





public class ProductCollection extends Product{
	
	//Adding objects in the list//
	private static ArrayList<Product> prodList=null;
	
	static
	{
		prodList=new ArrayList<Product>();
		Product p1=new Product(100,"TV","Electronics",40000.00);
		Product p2=new Product(101,"Pulses","Groceries",2500.00);
		Product p3=new Product(102,"Induction","Home Appliances",60000.00);
		Product p4=new Product(103,"Teddy Bears","Toys",1000.00);
		
		prodList.add(p1);
		prodList.add(p2);
		prodList.add(p3);
		prodList.add(p4);
		System.out.println("-----------------------------");
		
		
	}
	
	public static void addProductDetails(Product prod)
	{
		prodList.add(prod);
	}

	public static ArrayList<Product> getprodList() {
		return prodList;
	}
	
	public static void display()
	{
	for(Product ee: prodList)
		System.out.println(ee.toString());
		
	}
	
	//Displaying the discount
	public static void displayDiscount()
	{
		double price=0.00d;
		double calc=0;
		String prodType=null;
		for(Product err: prodList)
		{
			System.out.println(err.toString());
			price=err.getProdPrice();
			
			if(prodType=="Groceries")
			{
				calc=price*0.10;
				System.out.println("Total dicount: "+calc);
				System.out.println("--------------------------");
			}
			else if(prodType=="Toys")
			{
				calc=price*0.20;
				System.out.println("Total discount: "+calc );
				System.out.println("--------------------------");
			}
			else
			{
				calc=price*0.40;
				System.out.println("Total discount: "+calc);
				System.out.println("--------------------------");
			}
			
		}
		System.out.println("Total count of products: " + prodList.size());
	}
	
	
	
	
		
	}

