package com.cg.bean.product;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProductValidate {
	
	public static boolean isValidateprodId(String prodId)
	{
		Pattern newPattern=Pattern.compile("[0-9]{3}");
		Matcher matcher=newPattern.matcher( prodId);
		return matcher.matches();
		
	}

	public static boolean isValidateprodName(String prodName) 
	{
		Pattern newPattern=Pattern.compile("^[A-Z][a-z]{1,10}$");
		Matcher matcher=newPattern.matcher( prodName);
		return matcher.matches();
		
	}
	
	public static boolean isValidateprodType(String prodType)
	{
		Pattern newPattern=Pattern.compile("^[A-Z]{1}[a-z0-9- ]+$");
		Matcher matcher=newPattern.matcher( prodType);
		return matcher.matches();
	}
	
	public static boolean isValidateprodprodPrice(String prodPrice)
	{
	Pattern newPattern=Pattern.compile("^\\d+\\.\\d{1,2}$");
	Matcher matcher=newPattern.matcher( prodPrice);
	return matcher.matches();
	}

}
