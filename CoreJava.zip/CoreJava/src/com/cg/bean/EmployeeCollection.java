package com.cg.bean;

import java.util.ArrayList;
import java.util.Iterator;

/*import java.util.Scanner;*/

public class EmployeeCollection extends Employee {
	
	private static ArrayList<Employee> empList=null;
	static
	{
		empList=new ArrayList<Employee>();
		Employee e1=new Employee(101,"Pradeep","MTYHG78968",2500002.00);
		Employee e2=new Employee(102,"Ankita","DFGRT98499",335000.00);
		
		empList.add(e1);
		empList.add(e2);
	}
	
	
	public EmployeeCollection() {}

	
	public static void addEmployeeDetails(Employee emp1)
	{
		empList.add(emp1);
	}
	
	
	public static ArrayList<Employee> getempList() {
		return empList;
	}
	
	public static void display()
	{
	for(Employee ee: empList)
		System.out.println(ee.toString());
		
	}
	
    /*public void displayEmpCount()
    {
    	
    	Iterator<Employee> empIt=empList.iterator();
    	Employee tempEmp=null;
    	int totalCount=0;
    	while(empIt.hasNext())
    	{
    		totalCount++;
    	tempEmp=empIt.next();
    	System.out.println(tempEmp);
    	
    	}
    	System.out.println("Total Count  of Employees" +totalCount);
    }*/
    
   public static void displayAmt() {
    	
	   double Sal=0.00d;
    	double tax=0;
    	 for(Employee err: empList)
    	 {
    		 System.out.println(err.toString());
    		 Sal=err.getSalary();
    		 if(Sal<250000d)
    	    	{
    	    		System.out.println("Nil");
    	    		
    	    	}
    		 else if((Sal>250001) && (Sal<500000))
    	    	{
    	    		tax=Sal*0.10;
    	    		System.out.println("Tax Amount is " +tax);
    	    		System.out.println("--------------------------------");
    	    	}
    		 else /*if((Sal>500001) && (Sal<1000000))*/
    	    	{
    	    		tax=Sal*0.20;
    	    		System.out.println("Tax Amount is " +tax);
    	    		System.out.println("--------------------------------");
    	    	}
    		 System.out.println("Total count of Employees: " + empList.size());	
    		 
    	 }
    	
    	
    	
    	
    }
  
    
}
