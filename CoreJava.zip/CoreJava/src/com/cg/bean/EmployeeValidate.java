package com.cg.bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeValidate extends Employee {
	public static boolean isValidateempId(String empId)
	{
		/*String t=Integer.toString(empId);*/
		Pattern newPattern=Pattern.compile("[0-9]{3}");
		Matcher matcher=newPattern.matcher(empId);
		return matcher.matches();
	}
	
	public static boolean isValidateempName(String empName) 
	{
		
		Pattern newPattern=Pattern.compile("^[A-Z]{1}[a-z]{2,}$");
		Matcher matcher=newPattern.matcher(empName);
		return matcher.matches();
	}

	public static boolean isValidatepanCardNumber(String panCardNumber) 
	{
		Pattern newPattern=Pattern.compile("[A-Z]{5}[0-9]{5}");
		Matcher matcher=newPattern.matcher(panCardNumber);
		return matcher.matches();
	}
	
	public static boolean isValidatesalary(String salary)
	{
		
		Pattern newPattern=Pattern.compile("[0-9]+([,.][0-9]{1,2})?");
		Matcher matcher=newPattern.matcher(salary);
		return matcher.matches();
		
	}

	
	
}
