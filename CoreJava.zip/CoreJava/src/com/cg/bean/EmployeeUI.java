package com.cg.bean;

import java.util.Scanner;

public class EmployeeUI extends Employee{
	
	  static Scanner sc=new Scanner(System.in);
	  static EmployeeCollection coll=null;
	
	  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("Enter employees");
		n=sc.nextInt();
		EmployeeUI add[]=new EmployeeUI[n];
		
		
		while(true)
		{
			System.out.println("1.Add Employee Details:");
			System.out.println("2.Display Income Tax");
			System.out.println("3.Exit");
			
			System.out.println("Enter your choice");
			int ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				addEmployeeDetails();
				/*for(int i=0;i<n;i++)
				{
					add[i]=new EmployeeUI();
					add[i].addEmployeeDetails();
				}*/
				
				break;
			case 2:
				
				/*for(int i=0;i<n;i++)
				{
					System.out.println(add[i]);
					System.out.println();
				}*/
				displayTax();
				break;
				
				//coll.displayEmpCount();
				/*coll.displayAmt();*/
				
				
				
			case 3:
				sc.close();
				System.exit(0);
			}
		}
		
		

	}
	
	public static  void addEmployeeDetails() {
		Scanner sc=new Scanner(System.in);
		do {
			
		
		System.out.println("Enter Ur Employee ID:");
		String empId=sc.next();
		
		if(EmployeeValidate.isValidateempId(empId))
		{
			System.out.println("Enter the Name:");
			String empName=sc.next();
			
		if(EmployeeValidate.isValidateempName(empName))
		{
			System.out.println("Enter the Pan :");
			String PanCardNumber=sc.next();
		if(EmployeeValidate.isValidatepanCardNumber(PanCardNumber))
		{
			System.out.println("Enter the Salary:");
			String salary=sc.next();
			if(EmployeeValidate.isValidatesalary(salary))
			{	
				Employee emp1=new Employee(Integer.parseInt(empId),empName,PanCardNumber,Double.parseDouble(salary));
				EmployeeCollection.addEmployeeDetails(emp1);
				break;
				/*coll.displayEmpCount();
				coll.displayAmt();*/
				
			}
			else
				System.out.println("You entered wrong salary");
		}
		
		else
			System.out.println("You entered wrong pan");
		}
		else
			System.out.println("You entered wrong name");
		}
		else
			System.out.println("You entered wrong ID");
		
		
	}
	while(true);
	System.out.println("Details added successfully");

	}
	
	 public static void displayTax()
	 {
		    System.out.println("Income Range   \t Income Tax Amount");
			System.out.println("-----------------------------------");
			System.out.println("Upto 2,50,000  \t Nil");
			System.out.println("Above 2,50,001 to 5,00,000  \t 10%");
			System.out.println("Above 5,00,001 to 10,00,000  \t 20%");
			EmployeeCollection.displayAmt();
	 }

	
	
}
