package com.cg.bean;

public class Employee {
	
	int EmpId;
	String EmpName;
	String PanCardNumber;
    Double Salary;
	
	
	//Generating Default Constructors
	public Employee() {
		super();
	}
	
	
	   //Generating Parameterized Constructor
		public Employee(int empId, String empName, String panCardNumber, Double salary) {
		super();
		EmpId = empId;
		EmpName = empName;
		PanCardNumber = panCardNumber;
		Salary = salary;
	}






	//Generating Getters and Setters
	public int getEmpId() {
		return EmpId;
	}
	
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getPanCardNumber() {
		return PanCardNumber;
	}
	public void setPanCardNumber(String panCardNumber) {
		PanCardNumber = panCardNumber;
	}
	public Double getSalary() {
		return Salary;
	}
	public void setSalary(Double salary) {
		Salary = salary;
	}


	@Override
	public String toString() {
		return /*toString()+*/"Employee [EmpId=" + EmpId + "\n EmpName=" + EmpName + "\n PanCardNumber=" + PanCardNumber + "\n Salary="
				+ Salary + "]";
	}
	
	

	
}
