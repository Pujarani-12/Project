package com.employee.details;

public class Employee {
	
	int empId;
	String ename;
	String e_pan;
	Double salary;
	public Employee(int empId, String ename, String e_pan, Double salary) {

		this.empId = empId;
		this.ename = ename;
		this.e_pan = e_pan;
		this.salary = salary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getE_pan() {
		return e_pan;
	}
	public void setE_pan(String e_pan) {
		this.e_pan = e_pan;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	public String toString()
	{
		System.out.println("--------------------------------------------");
		return ("EID= "+empId+"\n"+"ENAME= "+ename+"\n"+"EPAN= "+e_pan+"\n"+"Salary= "+salary);
	}
	

}
