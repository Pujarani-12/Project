package com.employee.details;

public @interface BeforeClass {

}
