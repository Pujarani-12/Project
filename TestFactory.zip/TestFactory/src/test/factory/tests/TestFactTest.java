package test.factory.tests;




import org.dom4j.Document;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import test.factory.pages.TestFactPages;

public class TestFactTest {
	
	WebDriver driver;
	Document document;
	TestFactPages tfp;
	String fpath="From/";
	String gpath="round/";
	String tpath="To/";
	  //String fvalue="//goibibo/data/";
	
	@BeforeMethod
	  public void abc() throws Exception {
		 tfp=new TestFactPages(driver);
		  tfp.fileOpenXml();  
		  tfp.fileOpenProperty(); 
		  
		// tfp.getBrowser("Google");		 
		 
	  }

	
	@Test
	public void f() throws Exception {
		//tfp.inputField();
		tfp.radioButton(fpath);
		tfp.sendData(fpath);
		tfp.sendData(tpath);
		
	}


}
