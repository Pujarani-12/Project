package com.cg.bean.student;

import java.util.Scanner;

public class StudentUI {
	static Scanner sc=new Scanner(System.in);
	static StudentCollection coll=null;

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		
		while(true)
		{
			System.out.println("-----------------Student Details--------------------");
			System.out.println("1.Add Student Details");
			System.out.println("2.Display Student Details");
			System.out.println("3.Exit");
			
			System.out.println("Enter ur Choice");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				addStudentDetails();
				break;
			
			case 2:
				display();
				break;
				
			case 3:
				sc.close();
				System.exit(0);
			
			default:
				System.exit(0);
			}
		}

	}
	
	
	public static void addStudentDetails()
	{
		Scanner sc=new Scanner(System.in);
		
		do {
			System.out.println("---------------------------------");
			System.out.println("Enter Student Id");
			String studId=sc.next();
			
			if(StudentValidate.isValidatestudId(studId))
			{
				System.out.println("Enter the Student Name");
				String studName=sc.next();
				
			if(StudentValidate.isValidatestudName(studName))
			{
				System.out.println("Enter Grade");
				String grade=sc.next();
			if(StudentValidate.isValidategrade(grade))
			{
				System.out.println("Enter Marks");
				String Marks=sc.next();
			if(StudentValidate.isValidateMarks(Marks))
			{
				Student stud=new Student(Integer.parseInt(studId),studName,grade,Double.parseDouble(Marks));
				StudentCollection.addStudentDetails(stud);
				break;
			}
			else
				System.out.println("Please enter valid Marks between 0-100");
			}
			else
				System.out.println("Please enter a Valid Grade");
			}
			else
				System.out.println("Please enter a valid Student Name");
			}
			else
				System.out.println("Please enter a valid Student Id");
		}
		while(true);
		System.out.println("The details have been updates successfully");
	}
	
	public static void display()
	{
		System.out.println("----------------Marks Scheme----------------");
		System.out.println(" Grade                \t Marks Range");
		System.out.println("  A                       90-100");
		System.out.println("  B                     \t80-89");
		System.out.println("  C                      \t70-79");
		System.out.println("  D                       \t60-69");
		System.out.println("  E                        \t50-59");
		System.out.println("  F                         \tFail");
		StudentCollection.displayGrade();
	}

}
