package com.cg.bean.student;

public class Student {
	int StudentId;
	String StudentName;
	String Grade;
	Double Marks;
	
	
	
	public Student() {
		super();
	}



	public Student(int studentId, String studentName, String grade, Double marks) {
		super();
		StudentId = studentId;
		StudentName = studentName;
		Grade = grade;
		Marks = marks;
	}



	public int getStudentId() {
		return StudentId;
	}



	public void setStudentId(int studentId) {
		StudentId = studentId;
	}



	public String getStudentName() {
		return StudentName;
	}



	public void setStudentName(String studentName) {
		StudentName = studentName;
	}



	public String getGrade() {
		return Grade;
	}



	public void setGrade(String grade) {
		Grade = grade;
	}



	public Double getMarks() {
		return Marks;
	}



	public void setMarks(Double marks) {
		Marks = marks;
	}



	@Override
	public String toString() {
		return "Student [StudentId=" + StudentId + ", StudentName=" + StudentName + ", Grade=" + Grade + ", Marks="
				+ Marks + "]";
	}
	
	
	
	
	

}
