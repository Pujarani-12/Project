package com.cg.bean.student;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentValidate extends Student{
	
	
	public static boolean isValidatestudId(String studId)
	{
		Pattern newPattern=Pattern.compile("[0-9]{3}");
		Matcher matcher=newPattern.matcher(studId);
		return matcher.matches();
	}
	
	public static boolean isValidatestudName(String studName)
	{
		Pattern newPattern=Pattern.compile("^[A-Z][a-z]{1,}$");
		Matcher matcher=newPattern.matcher(studName);
		return matcher.matches();
	}
	
	public static boolean isValidategrade(String grade)
	{
		Pattern newPattern=Pattern.compile("^[A-F]{1}$");
		Matcher matcher=newPattern.matcher(grade);
		return matcher.matches();
	}
	
	
	public static boolean isValidateMarks(String Marks)
	{
		Pattern newPattern=Pattern.compile("[0-9]{2}[0]{3}");
		Matcher matcher=newPattern.matcher(Marks);
		return matcher.matches();
	}

}
