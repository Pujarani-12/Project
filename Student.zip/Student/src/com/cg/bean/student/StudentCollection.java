package com.cg.bean.student;

import java.util.ArrayList;





public class StudentCollection extends Student{
	
	private static ArrayList<Student> studList=null;
	static
	{
		studList=new ArrayList<Student>();
		Student s1=new Student(300,"Ashish","B",80.12);
		Student s2=new Student(301,"Gyan","F",40.00);
		
		studList.add(s1);
		studList.add(s2);
		
	}
	
	
	public static void addStudentDetails(Student stud)
	{
		studList.add(stud);
	}
	
	
	public static ArrayList<Student> getempList() {
		return studList;
	}
	
	
	public static void display()
	{
	for(Student ee: studList)
	{
		System.out.println(ee.toString());
		
	
	}
	}
	
	public static void displayGrade()
	{
		double Marks=0;
		for(Student err: studList)
		{
			System.out.println(err.toString());
			Marks=err.getMarks();
		}
		
		//String grade=null;
		
		if((Marks>=90) && (Marks<=100))
		{
			System.out.println("Grade is: A");
		}
		
		else if((Marks>=80) && (Marks<=89))
		{
			System.out.println("Grade is: B");
		}
		else if((Marks>=70) && (Marks <=79))
		{
			System.out.println("Grade is: C");
		}
		else if((Marks>=60) && (Marks<=69))
		{
			System.out.println("Grade is: D");
		}
		else if((Marks>=50) && (Marks<=59))
		{
			System.out.println("Grade is: E");
		}
		else
		{
			System.out.println("Grade is: F");
		}
		System.out.println("Total number of Students:" +studList.size());
	}
	}


