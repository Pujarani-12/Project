package com.cg.bean.book;

public class Book {
	int bookId;
	String bookName;
	String bookType;
	Float bookPrice;
	
	
	public Book() {
		super();
	}


	public Book(int bookId, String bookName, String bookType, Float bookPrice) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookType = bookType;
		this.bookPrice = bookPrice;
	}


	public int getBookId() {
		return bookId;
	}


	public void setBookId(int bookId) {
		this.bookId = bookId;
	}


	public String getBookName() {
		return bookName;
	}


	public void setBookName(String bookName) {
		this.bookName = bookName;
	}


	public String getBookType() {
		return bookType;
	}


	public void setBookType(String bookType) {
		this.bookType = bookType;
	}


	public Float getBookPrice() {
		return bookPrice;
	}


	public void setBookPrice(Float bookPrice) {
		this.bookPrice = bookPrice;
	}


	@Override
	public String toString() {
		return "Book bookId=" + bookId + "\n bookName=" + bookName + "\n bookType=" + bookType + "\n bookPrice="
				+ bookPrice + "]";
	}
	
	
	
	

}
