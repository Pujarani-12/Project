package com.cg.bean.book;

import java.util.ArrayList;
import java.util.Iterator;







public class BookCollection extends Book{
	
	private static ArrayList<Book> bookList=null;
	static
	{
		bookList=new ArrayList<Book>();
		Book b1=new Book(200,"See Into the Sea of C","Regular",(float)350.00);
		Book b2=new Book(201,"Adventures Of Tintin","Cartoon",(float)250.00);
		Book b3=new Book(202,"Romeo and Juliet","Novel",(float)500.00);
		
		bookList.add(b1);
		bookList.add(b2);
		bookList.add(b3);
		
		
	}
	
	public static void addBookDetails(Book bk)
	{
		bookList.add(bk);
	}
	
	
	public static ArrayList<Book> getbookList() {
		return bookList;
	}
	
	public static void setbookList(ArrayList<Book> bookList)
	{
		BookCollection.bookList=bookList;
	}
	
	
	public static void display()
	{
	for(Book ee: bookList)
		System.out.println(ee.toString());
		
	}
	
	public static void displayBookCount()
	{
		Iterator<Book> bookIt=bookList.iterator();
		Book tempBook=null;
		
		int count=0;
		while(bookIt.hasNext())
		{
			count++;
			tempBook=bookIt.next();
			System.out.println(tempBook);
		}
		System.out.println("Total number of books is:" +count);
		
	}

}
