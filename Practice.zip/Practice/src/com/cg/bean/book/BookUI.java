package com.cg.bean.book;

import java.util.Scanner;

public class BookUI extends Book {
	
	static Scanner sc=new Scanner(System.in);
	static BookCollection coll=null;
	
public  void addBookDetails() {
	Scanner sc=new Scanner(System.in);
		
	do {
			System.out.println("----------Book Details------------");
			System.out.println("Enter your Book Id");
			String bookId=sc.next();
			if(BookValidate.isValidatebookId(bookId))
			{
				System.out.println("Enter your Book Name");
				String bookName=sc.next();
				if(BookValidate.isValidatebookName(bookName))
				{
					System.out.println("Enter your Book Type");
					String bookType=sc.next();
					if(BookValidate.isValidatebookType(bookType))
					{
						System.out.println("Enter your Book Price");
						String bookPrice=sc.next();
					if(BookValidate.isValidatebookPrice(bookPrice))
						{
						Book bk=new Book(Integer.parseInt(bookId),bookName,bookType,Float.parseFloat(bookPrice));
						BookCollection.addBookDetails(bk);
						break;
						}
					else
						System.out.println("Please enter a valid bookPrice");
					}
					else
						System.out.println("Please enter a valid bookType");
					
				}
				else
					System.out.println("Please enter a valid book Name");
					
			}
			else
				System.out.println("Please enter a valid book Id");
			
		}
		
		
		while(true);
		
		System.out.println("Book Details been updated successfully");
		}
		
	
	

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int bcount;
		System.out.println("How many books?");
		bcount=sc.nextInt();
		 BookUI add[]=new BookUI[bcount];
		
		while(true)
		{
			System.out.println("--------Book Details---------");
			System.out.println("1.Add Book Details");
			System.out.println("2.Display Book Details");
			System.out.println("3.Exit");
			
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				for(int i =0;i<bcount;i++)
				{
					add[i]=new BookUI();
					add[i].addBookDetails();
					
					
				}
				//addBookDetails();
				break;
			
			case 2:
				for(int i =0;i<bcount;i++)
				{
					System.out.println(add[i]);
					System.out.println();
				}
				//display();
				break;
				
			case 3:
				sc.close();
				System.exit(0);
			default:
				System.exit(0);
			
			}
		}
		
	
		}
	
public static void display()
	
	{
		BookCollection.display();
	}

}
