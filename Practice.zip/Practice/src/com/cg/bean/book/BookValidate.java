package com.cg.bean.book;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BookValidate extends Book {
	
	public static boolean isValidatebookId(String bookId)
	{
		Pattern newPattern=Pattern.compile("[0-9]{3}");
		Matcher matcher=newPattern.matcher(bookId);
		return matcher.matches();
	}
	
	
	public static boolean isValidatebookName(String bookName)
	{
	Pattern newPattern=Pattern.compile("^[A-Za-z]{6,}$");
	Matcher matcher=newPattern.matcher(bookName);
	return matcher.matches();
	}
	
	public static boolean isValidatebookType(String bookType)
	{
		Pattern newPattern=Pattern.compile("^[A-Z][a-z]{1,10}$");
		Matcher matcher=newPattern.matcher(bookType);
		return matcher.matches();
	}
	
	public static boolean isValidatebookPrice(String bookPrice)
	{
		Pattern newPattern=Pattern.compile("^\\d+\\.\\d{1,2}$");
		Matcher matcher=newPattern.matcher(bookPrice);
		return matcher.matches();
	}

}
